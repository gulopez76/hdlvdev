<span <?php print drupal_attributes($attributes); ?>><a href="#"><?php print t('Next'); ?></a></span>
