<div<?php print drupal_attributes($attributes); ?>>
  <?php print $rendered_items; ?>
</div>
