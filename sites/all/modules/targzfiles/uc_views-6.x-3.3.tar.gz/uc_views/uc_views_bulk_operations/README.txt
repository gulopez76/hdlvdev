
Welcome to Ubercart Views with Bulk operations.
-----------------------------------------------

This module is an extension set of uc_views that allows the use of bulk operations.

Great thanks to 'thill_' for providing the patch that made this possible!