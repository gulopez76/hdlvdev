<?php

/**
 * @file
 * Patch by hanoii
 */

/**
 * @file uc-views-view-row-invoice.tpl.php
 * Default simple view template to display a single invoice.
 *
 * @ingroup views_templates
 */
?>
<?php print $invoice ?>