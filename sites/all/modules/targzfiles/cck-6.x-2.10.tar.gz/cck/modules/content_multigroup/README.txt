; $Id$

Ongoing work on the multigroup module has moved to the experimental
CCK 3.0 branch.
