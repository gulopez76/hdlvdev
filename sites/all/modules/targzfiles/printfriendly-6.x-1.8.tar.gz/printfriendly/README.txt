/* $Id: README.txt,v 1.3 2009/07/01 19:00:11 anon Exp $ */

-- SUMMARY --

This module gives your site the ability to use printfriendly.com's awesome print service.

What it does is that it’s simply creates a block and/or a link in the node links section to directly call printfriendly.com's print service.

-- REQUIREMENTS --

Drupal 6.x

-- INSTALLATION --

Normal Drupal module installation, see http://drupal.org/node/70151 for further information.

-- CONFIGURATION --

This module provides three ways to integrate the Printfriendly button.

1 a) Display Printfriendly button in the node links section.
* Go to Administer / Site configuration / Printfriendly. <http://example.com/admin/settings/printfriendly>
* Check Display on node pages.
* If you want to limit the Printfriendly button visibility by content type, go to Administer / Content management / Content types <http://example.com/admin/content/types/list> and choose a content type. Visibility can be set for each content type under Workflow settings.

1 b) Display Printfriendly button in the node links section (but not as default)
* Edit the node
* Check/uncheck the printfriendly button to show/hide the button.

2) Use Printfriendly as a block.
* Go to Site building / Blocks <http://example.com/admin/admin/build/block>  and make Printfriendly button block visible.

-- CUSTOMIZATION --

You have a number of options available at Administer / Site configuration / Printfriendly <http://example.com/admin/settings/printfriendly>
 
If configuration options are not flexible enough for you it is also possible to override 
- theme_printfriendly_button_base (the button container)
- theme_printfriendly_type_1 (theme for button type 1)
- theme_printfriendly_type_2 (theme for button type 2)
- theme_printfriendly_type_3 (theme for button type 3)
- theme_printfriendly_type_4 (theme for button type 4)
- theme_printfriendly_type_5 (theme for button type 5)
- theme_printfriendly_type_6 (theme for button type 6)
- theme_printfriendly_type_7 (theme for button type 7)
in your own theme.

-- CONTACT --

Current maintainers:
* Emil Stjerneman (anon) - http://drupal.org/user/464598

