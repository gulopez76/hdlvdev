This module changes your forum administration page to let you apply role-based
permissions to each forum, and to give each forum individual moderators.

Moderators automatically get all privileges on all posts in that forum,
including edit and delete.
