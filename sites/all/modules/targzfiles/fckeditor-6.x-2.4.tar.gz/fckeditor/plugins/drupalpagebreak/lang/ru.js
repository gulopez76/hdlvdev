FCKLang.DrupalPageBreakTooltip = 'Вставить разрыв страницы' ;
FCKLang.DrupalPageBreakTitle = 'Страница' ;
