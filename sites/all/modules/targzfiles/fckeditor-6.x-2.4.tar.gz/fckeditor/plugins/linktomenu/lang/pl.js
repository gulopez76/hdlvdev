FCKLang.DlgBrowse				= 'Przeglądaj' ;
FCKLang.DlgLoading				= 'Ładowanie...' ;
FCKLang.DlgLinkToMenu			= 'Link do menu' ;
FCKLang.DlgTitle				= 'Tytuł' ;
FCKLang.DlgChooseCategory		= 'Wybierz' ;