<?php
/**
 * @file
 * Definition of MailhandlerRetrieveDummy class.
 */

/**
 * Retrieve messages from a Mailhandler Mailbox.
 */
class MailhandlerRetrieveDummy extends MailhandlerRetrieve {
}
